<?php
// Heading
$_['heading_title']    = 'Модули';

// Text
$_['text_success']     = 'Настройки успешно обновлены!';
$_['text_layout']      = 'После установки и настройки модуля вы можете добавить его на макет в разделе <a href="%s" class="alert-link">Система - Дизайн - Макеты</a>!';
$_['text_list']        = 'Модули';

// Column
$_['column_name']      = 'Название модуля';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'У Вас нет прав для управления модулем!';

