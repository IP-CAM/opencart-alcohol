<?php
// Heading
$_['heading_title']	   = 'Журнал ошибок';

// Text
$_['text_success']	   = 'Журнал ошибок очищен!';
$_['text_list']        = 'Ошибки';

// Error
$_['error_warning']	   = 'Внимание: Ваш  файл ошибок %s is %s!';
$_['error_permission'] = 'У Вас нет прав для управления данным модулем!';

