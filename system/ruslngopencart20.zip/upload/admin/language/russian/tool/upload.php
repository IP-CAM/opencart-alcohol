<?php
// Heading
$_['heading_title']     = 'Загрузки';

// Text
$_['text_success']      = 'Выполнено!';
$_['text_list']         = 'Загрузки';

// Column
$_['column_name']       = 'Имя загрузки';
$_['column_filename']   = 'Имя Файла';
$_['column_date_added'] = 'Дата добавления';
$_['column_action']     = 'Действие';

// Entry
$_['entry_name']        = 'Имя загрузки';
$_['entry_filename']    = 'Имя Файла';
$_['entry_date_added'] 	= 'Дата добавления';

// Error
$_['error_permission']  = 'У Вас нет прав для управления данным модулем!';

