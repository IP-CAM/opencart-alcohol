<?php
// Text
$_['text_voucher'] = 'Подарочный сертификат (%s)';

