<?php
$_['text_total'] = 'Итого';

