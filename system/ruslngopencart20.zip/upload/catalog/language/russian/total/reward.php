<?php
// Text
$_['text_reward']   = 'Бонусные баллы (%s)';
$_['text_order_id'] = 'Заказ №: %s';

