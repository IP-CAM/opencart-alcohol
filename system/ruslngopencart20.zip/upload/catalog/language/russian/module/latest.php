<?php
// Heading
$_['heading_title'] = 'Новые поступления';

// Text
$_['text_tax']      = 'Без НДС:';

