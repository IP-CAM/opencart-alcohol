<?php

// Text

$_['text_subject']  = '%s - Новый пароль';

$_['text_greeting'] = 'Новый пароль был запросил %s.';

$_['text_password'] = 'Ваш новый пароль:';

